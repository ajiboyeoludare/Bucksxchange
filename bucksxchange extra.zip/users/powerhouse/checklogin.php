<?php
function check_userslogin()
{
if(strlen($_SESSION['email'])==0)
	{	
		$host = $_SERVER['HTTP_HOST'];
		$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra="../index";		
		$_SESSION["id"]="";
		header("Location: http://$host$uri/$extra");
	}
}
?>