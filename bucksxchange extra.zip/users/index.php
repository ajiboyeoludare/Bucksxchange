<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_userslogin();

?>
<!doctype html>
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">


    <title>Welcome !! <?php echo $_SESSION['email']; ?></title>

    <!-- Bootstrap -->
    <link href="css/navbar.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   
</div><!--Preloader -->

<?php

require_once('header.php');
?>

<style type="text/css">
	.rates table th {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
		color: #fff;
	}
	.rates table {
		width: 100%;
	}

	.rates table td {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
	}

	table td h6 {
		padding: 4px;
		margin-bottom: 0px;
	}
</style>
<div class="container margin_default" style="margin-bottom: 50px;">
	<div class="row">

		<div class="col-lg-12" id="faq">
			<div style="margin: 15px 0 15px 0;text-align: right;">
				<a href="rates" class="btn btn-secondary"><i class="fa fa-plus"></i>New Trade</a>
			</div>
			
			
			<div role="tablist" class="add_bottom_45 accordion_2" id="payment">
				<div class="card">
					<div class="card-header" role="tab">
						<h5 class="mb-0">
							<a data-toggle="collapse" href="#collapseOne_payment" aria-expanded="true"><i class="indicator ti-minus"></i>Pending Trades</a>
						</h5>
					</div>

					<div id="collapseOne_payment" class="collapse show" role="tabpanel" data-parent="#payment">
						<div class="card-body">
						 
			<div class="form-group">
										
											
											<table id="data-table" class="table table-striped table-hover dt-responsive" cellspacing="0" width="100%"   style="border: 1px solid grey;">
            <thead>
	            <tr>	    
                      <th class="text-center width-100" style="border-right: 1px solid grey;">Total Price</th>				
	                <th class="text-center width-100"  style="border-right: 1px solid grey;">Card</th>
					<th class="text-center width-100" style="border-right: 1px solid grey;">Account Details</th>
	                 
	                
	            </tr>
				
			
			
				
				<tbody>
				<?php
				$email=$_SESSION['email'];
				$checkhandle=mysqli_query($mysqli,"SELECT email FROM pendingtrade WHERE email='$email'");
				if(mysqli_num_rows($checkhandle)==0)
				{
					echo '<div class="alert alert-danger">
										No Pending Trades!
									</div>';
					
				}
				?>	
				<?php

            

           $email=$_SESSION['email'];
	
	/// select first 3 posts
            $query = "SELECT * FROM pendingtrade WHERE email='$email'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){
         $bankname = $row['bankname'];
		 $total = $row['total'];
		 $cardname = $row['cardname'];
		 $accountname = $row['accountname'];
		 $accountnumber = $row['accountnumber'];
		 ?>
		 <tr>
				<td  style="border-right: 1px solid grey;">&#8358;<?php echo number_format( $total); ?></td>
				<td style="border-right: 1px solid grey;"><?php echo $cardname; ?> card</td>
				<td style="border-right: 1px solid grey;"><?php echo $bankname; ?> &nbsp; <?php echo $accountname; ?> &nbsp; <?php echo $accountnumber; ?></td>
				</tr>
				<?php } ?></tbody>
				
									
				
            </thead>
			</table>
										
								
									</div>
											
										
																
															</div>
						</div>
					</div>
					<!-- /card -->
					<div class="card">
						<div class="card-header" role="tab">
							<h5 class="mb-0">
								<a class="collapsed" data-toggle="collapse" href="#collapseTwo_payment" aria-expanded="false">
									<i class="indicator ti-plus"></i>Trade History
								</a>
							</h5>
						</div>
						<div id="collapseTwo_payment" class="collapse" role="tabpanel" data-parent="#payment">
							<div class="card-body">
								<div class="card-body">
																														<table id="data-table" class="table table-striped table-hover dt-responsive" cellspacing="0" width="100%"   style="border: 1px solid grey;">
            <thead>
	            <tr>	    
                      <th class="text-center width-100" style="border-right: 1px solid grey;">Total Price</th>				
	                <th class="text-center width-100"  style="border-right: 1px solid grey;">Card</th>
					<th class="text-center width-100" style="border-right: 1px solid grey;">Account Details</th>
	                 
	                
	            </tr>
				
			
			
				
				<tbody>
				<?php
				$email=$_SESSION['email'];
				$checkhandle=mysqli_query($mysqli,"SELECT email FROM alltrade WHERE email='$email'");
				if(mysqli_num_rows($checkhandle)==0)
				{
					echo '<div class="alert alert-danger">
										You have not made any  Trade yet!
									</div>';
					
				}
				?>	
				<?php

            

           $email=$_SESSION['email'];
	
	/// select first 3 posts
            $query = "SELECT * FROM alltrade WHERE email='$email'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){
         $bankname = $row['bankname'];
		 $total = $row['total'];
		 $cardname = $row['cardname'];
		 $accountname = $row['accountname'];
		 $accountnumber = $row['accountnumber'];
		 ?>
		 <tr>
				<td  style="border-right: 1px solid grey;">&#8358;<?php echo number_format( $total); ?></td>
				<td style="border-right: 1px solid grey;"><?php echo $cardname; ?> card</td>
				<td style="border-right: 1px solid grey;"><?php echo $bankname; ?> &nbsp; <?php echo $accountname; ?> &nbsp; <?php echo $accountnumber; ?></td>
				</tr>
				<?php } ?></tbody>
				
									
				
            </thead>
			</table>
																			</div>
								</div>
							</div>
						</div>
						<!-- /card -->
						<!-- /card -->
					</div>
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!--/container-->
       <?php

require_once('footer.php');
?>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>