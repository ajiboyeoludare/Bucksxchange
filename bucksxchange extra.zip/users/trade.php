<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_userslogin();

$name = $_GET['name'];
	
	//check if id not exist in database///////////
	 $checkname=mysqli_query($mysqli,"SELECT * FROM card WHERE name='$name'");
     if(mysqli_num_rows($checkname)<1)
    {
	header('location: rates.php');
}
if(empty($name)) {
	header('location: rates.php');
}	 



//code for add courses
$accountnumberError =  $imageError =  "";
$twentyfive =  $fifty = $hundred = $twohundred  = $fivehundred = $onethousand =  "";
$bankname = $accountnumber = $accountname =  $number  = $image  = $total  =  $cardname = $email  =   "";



if (isset($_POST["submit"]))  {
//retrive form values
$cardname=mysqli_real_escape_string($mysqli,$_POST['cardname']);
$bankname=mysqli_real_escape_string($mysqli,$_POST['bankname']);
$accountnumber=mysqli_real_escape_string($mysqli,$_POST['accountnumber']);
$accountname=mysqli_real_escape_string($mysqli,$_POST['accountname']);
$number=mysqli_real_escape_string($mysqli,$_POST['number']);
$email=mysqli_real_escape_string($mysqli,$_POST['email']);
$twentyfive=mysqli_real_escape_string($mysqli,$_POST['twentyfive']);
$fifty=mysqli_real_escape_string($mysqli,$_POST['fifty']);
$hundred=mysqli_real_escape_string($mysqli,$_POST['hundred']);
$twohundred=mysqli_real_escape_string($mysqli,$_POST['twohundred']);
$fivehundred=mysqli_real_escape_string($mysqli,$_POST['fivehundred']);
$onethousand=mysqli_real_escape_string($mysqli,$_POST['onethousand']);
$total=  $twentyfive +  $fifty + $hundred + $twohundred + $fivehundred + $onethousand;

 
 $name = $_FILES['img']['name'];
  $target_dir = "images/";
  $target_file = $target_dir . basename($_FILES["img"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
 
    // Convert to base64 
    $image = $_FILES['img']['name'];
   
   
  
    // Upload file
    move_uploaded_file($_FILES['img']['tmp_name'],$target_dir.$name);
  }




 //validating firstname input value
	 if (empty($accountnumber)||strlen($accountnumber)<9) 
	 {
     $accountnumberError = "Account Number too short"; 
	 }
	 
	 if(!in_array($imageFileType,$extensions_arr))
		 {
     $imageError = "$imageFileType is not an allowed file type"; 
	 }
	 //insert into database
	  if (!$accountnumberError)		
		  if (!$imageError)	
	 {
	$sql="INSERT INTO pendingtrade (bankname,accountname,accountnumber,number,twentyfive,fifty,hundred,twohundred,fivehundred,onethousand,total,cardname,email,image) VALUES ('" . $_POST["bankname"] . "','" . $_POST["accountname"] . "','" . $_POST["accountnumber"] . "','" . $_POST["number"] . "','" . $_POST["twentyfive"] . "','$fifty','$hundred','$twohundred','$fivehundred','$onethousand','$total','$cardname','$email','$image')";
   mysqli_query($mysqli,$sql);
	$current_id = mysqli_insert_id($mysqli);
	
	
	
	
	
	
	//end insert room
	if(!empty($current_id)) {
		
		
		$email = "Bucksxchange bucksxchange@gmail.com";
		 $toEmail = "info@bucksxchange.com.ng";
			$subject = "New Trade initiated";
			$content = "A trade of " . number_format($total) . " NGN  was just initiated";
			// create email headers
$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
if(mail($toEmail, $subject, $content, $headers))
{
		$message = "Trade Initiated  Successfully,";
}
	}
}
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">


    <title>Welcome !! <?php echo $_SESSION['email']; ?></title>

    <!-- Bootstrap -->
    <link href="css/navbar.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div><!--Preloader -->

<?php

require_once('header.php');
?>

<style type="text/css">
	.rates table th {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
		color: #fff;
	}
	.rates table {
		width: 100%;
	}

	.rates table td {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
	}

	table td h6 {
		padding: 4px;
		margin-bottom: 0px;
	}
</style>
<div class="container margin_default" style="margin: 30px auto;">
	<div class="row">

		<div class="col-lg-12" id="faq">
			<div role="tablist" class="add_bottom_45 accordion_2" id="payment">
				
			  <?php

            

           $name = $_GET['name'];
	
	/// select first 3 posts
            $query = "SELECT * FROM card WHERE name='$name'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){

                
                $name = $row['name'];
				$image = $row['image'];
				$twentyfive = $row['twentyfive'];
				$fifty = $row['fifty'];
				$hundred = $row['hundred'];
				$twohundred = $row['twohundred'];
				$fivehundred = $row['fivehundred'];
				$onethousand = $row['onethousand'];
		  
		  
	  	?>	
		
		<div class="card">
					<div class="card-header" role="tab">
						<h5 class="mb-0">
							<a data-toggle="" href="javascript:;" aria-expanded="true">
								<?php echo $name;?> 
								<img src="images/<?php echo $image; ?>" class="float-right" style="width: 40px;" >
							</a>
						</h5>
					</div>
										<div id="collapseOne_payment" class="collapse show" role="tabpanel" data-parent="#payment">
						<div class="card-body">
							<div class="row">
								<div class="col-sm-1">&nbsp;</div>
								<div class="col-md-8 col-sm-12">
									
									<form method="post" action="" class="uploadForm" enctype="multipart/form-data">
											<font color="red"><h6><?php if(isset($message)) { echo $message; } ?></h6><br></font>
										<div class="form-group">
											<input type="hidden" name="cardname" value="<?php echo $name; ?>" readonly>
											<h5>Gift Card Details</h5>
											<table style="width: 100%;" cellpadding="10">
												
												
												<!-- Twenty Five -->	
                                                                                 
<?php 
					  if (empty($twentyfive)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$25</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculatetwentyfive(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="twentyfive" id="twentyfive" style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculatetwentyfive(val) {
                var tot_price = val * $twentyfive;
                /*display the result*/
                var divobj = document.getElementById('twentyfive');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										


<!--END OF TWENTY FIVE-->	


<!-- FIFTY -->	
                                                                                 
<?php 
					  if (empty($fifty)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$50</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculatefifty(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="fifty" id="fifty"  style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculatefifty(val) {
                var tot_price = val * $fifty;
                /*display the result*/
                var divobj = document.getElementById('fifty');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										
									 
<!--END OF fifty-->	
							

<!-- HUNDREDD -->	
                                                                                 
<?php 
					  if (empty($hundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$100</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculatehundred(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="hundred" id="hundred" style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculatehundred(val) {
                var tot_price = val * $hundred;
                /*display the result*/
                var divobj = document.getElementById('hundred');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										
					 
<!--END OF HUNDRED-->



<!-- TWO HUNDREDD -->	
                                                                                 
<?php 
					  if (empty($twohundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$200</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculatetwohundred(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="twohundred" id="twohundred"  style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculatetwohundred(val) {
                var tot_price = val * $twohundred;
                /*display the result*/
                var divobj = document.getElementById('twohundred');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										
							 
<!--END OF TWO HUNDRED-->




<!-- FIVE HUNDREDD -->	
                                                                                 
<?php 
					  if (empty($fivehundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$500</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculatefivehundred(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="fivehundred" id="fivehundred"  style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculatefivehundred(val) {
                var tot_price = val * $fivehundred;
                /*display the result*/
                var divobj = document.getElementById('fivehundred');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										
										 
<!--END OF FIVE HUNDRED-->	




<!-- ONE THOUSAND -->	
                                                                                 
<?php 
					  if (empty($onethousand)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo'<tr>
		 <td colspan="2" class="row" style="border-bottom: 1px solid #e1e1e1;">
															<div class="col-sm-2">
																<div style="position: relative;">
																	<img src="images/'.$image.'" alt="">
																	<div style="text-align:center;font-weight:bold;color:#fff;position: absolute;background: rgba(0,0,0,0.4);left: 0;top: 0;height: 100%;width: 100%;">
																		<span style="position: relative;top: 15px;">$1000</span>
																	</div>
																</div>
															</div>
															<div class="col-sm-2">
															</div>
															<div class="col-sm-6">
																<div class="form-group">
											<label>Denomination</label>
											<select name="bank" class="form-control" onchange="calculateonethousand(this.value)">
												<option value="" selected="selected" disabled="">-- Select the number of cards to sell --</option>
												<option value="1">1 piece</option>
												<option value="2">2 pieces</option>
												<option value="3">3 pieces</option>
												<option value="4">4 pieces</option>
												<option value="5">5 pieces</option>
												<option value="6">6 pieces</option>
												<option value="7">7 pieces</option>
												<option value="8">8 pieces</option>
												<option value="9">9 pieces</option>
												<option value="10">10 pieces</option>
												</select>
										</div>
															<div style="text-align: center;padding: 0px;">
															
																<font color="red">&#8358;</font><input type="text" name="onethousand" id="onethousand" style="border:1px solid white;color:red;background-color:white;" readonly>';
echo"<script>
            function calculateonethousand(val) {
                var tot_price = val * $onethousand;
                /*display the result*/
                var divobj = document.getElementById('onethousand');
                divobj.value = tot_price;
            }
        </script>";
		
		echo'</div>
														</td>
													</tr>';
	 }
	 ?>										
								 
<!--END OF ONE THOUSAND-->									
													
								






<!-- Total -->	
						 
<!--Total-->									
							













					
													
													
													
													
																																						
																							
											</table>
										</div>
										<div class="form-group">
											<h5>Bank Details</h5>
										</div>
										<div class="form-group">
											<label>Bank Name</label>
											<select name="bankname" class="form-control" required>
												<option value="" selected="selected" disabled="">-- Choose your Bank --</option>
												<option value="Access Bank Nigeria Plc">Access Bank Nigeria Plc</option><option value="Diamond Bank Plc">Diamond Bank Plc</option><option value="Ecobank Nigeria">Ecobank Nigeria</option><option value="Enterprise Bank Plc">Enterprise Bank Plc</option><option value="Fidelity Bank Plc">Fidelity Bank Plc</option><option value="First Bank of Nigeria Plc">First Bank of Nigeria Plc</option><option value="First City Monument Bank">First City Monument Bank</option><option value="Guaranty Trust Bank Plc">Guaranty Trust Bank Plc</option><option value="Keystone Bank Ltd">Keystone Bank Ltd</option><option value="Mainstreet Bank Plc">Mainstreet Bank Plc</option><option value="Skye Bank Plc">Skye Bank Plc</option><option value="Stanbic IBTC Plc">Stanbic IBTC Plc</option><option value="Sterling Bank Plc">Sterling Bank Plc</option><option value="Union Bank Nigeria Plc">Union Bank Nigeria Plc</option><option value="United Bank for Africa Plc">United Bank for Africa Plc</option><option value="Unity Bank Plc">Unity Bank Plc</option><option value="WEMA Bank Plc">WEMA Bank Plc</option><option value="Zenith Bank International">Zenith Bank International</option><option value="Heritage Bank">Heritage Bank</option><option value="Jaiz Bank">Jaiz Bank</option>
											</select>
										</div>
										<div class="form-group">
											<label>Account Number</label><br>
											<font color="red"><?php echo $accountnumberError;?></font>
											<input type="number" value="" name="accountnumber" class="form-control" placeholder="Account Number" required>
										</div>
										<div class="form-group">
											<label>Account Name</label>
											<input type="text" value="" name="accountname"class="form-control" placeholder="Account Name" required>
										</div>
										
										
		  <?php

            

           $email=$_SESSION['email'];
	
	/// select first 3 posts
            $query = "SELECT * FROM users WHERE email='$email'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){
         $number = $row['contactNo'];
		 
			?>
			<div class="form-group">
										
											<label>Contact Phone</label>
											<input type="text" name="number" placeholder="Phone Number" class="form-control" value="<?php echo $number;?>" required>
											<input type="hidden" name="email"  class="form-control" value="<?php echo $email;?>" required>
								
									</div>
										<?php } ?>	
										
										<div class="form-group">
										    <label><h5>Trading terms and conditions</h5></label>
										    <br>
											<label>
                        <input type="checkbox" value="agree" name="terms" required> &nbsp; Accept <a href="terms.php">terms and condition</a></label>
                        
                        
										</div>
										
											
										
										
										

										
										<div class="form-group">
											<h5 style="color: red;font-size: weigth;">Giftcard Images</h5>
											<div class="upload">Click to Upload</div>
										</div>
												<font color="red"><?php echo $imageError;?></font>								
										<input type="file" class="uploaded" style="margin-bottom:20px;" name="img" multiple  required>
										<button type="submit"  name="submit" class="btn btn-primary" style="background-color:#f51f8a;border-color:#f51f8a;color:white;">Initiate Trade</button>
									</form>
									<p>&nbsp;</p>
								</div>
								
							</div>
						</div>
				 	</div>
				</div>
	 <?php } ?>
			</div>
		</div>
		<!-- /col -->
	</div>
	<!-- /row -->
</div>

<!--/container-->




 <?php

require_once('footer.php');
?>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>