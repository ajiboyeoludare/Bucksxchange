<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_userslogin();

?>
<!doctype html>
<html lang="en">
<head>
   
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">


    <title>Welcome !! <?php echo $_SESSION['email']; ?></title>

    <!-- Bootstrap -->
    <link href="css/navbar.css" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   
</div><!--Preloader -->

<?php

require_once('header.php');
?>

<style type="text/css">
	.rates table th {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
		color: #fff;
	}
	.rates table {
		width: 100%;
	}

	.rates table td {
		outline: 1px solid #e1e1e1 !important;
		vertical-align: middle;
	}

	table td h6 {
		padding: 4px;
		margin-bottom: 0px;
	}
</style>

<section class="pricing-table section-padding-2" id="rates">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 centered wow fadeInUp" data-wow-delay="0.3s">
                <div class="section-title">
                    <h2>Rates </h2>
                    <p>Our competitive rates</p>
                </div>
            </div>
        </div>
		
        <div class="row">
                                              <?php

            

            // select first 3 posts
            $query = "select * from card";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){

                $id = $row['id'];
                $name = $row['name'];
				$twentyfive = $row['twentyfive'];
				$fifty = $row['fifty'];
				$hundred = $row['hundred'];
				$twohundred = $row['twohundred'];
				$fivehundred = $row['fivehundred'];
				$onethousand = $row['onethousand'];
				$image = $row['image'];
                $type = $row['type'];
				
	
						   ?>              <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.4s">
                   
						   <div class="single-pricing-table">
                        <h3><?php echo $name;?></h3>
                        <h4><img src="../images/<?php echo $image; ?>" alt=""></h4>
                        
                        <center><table class="table table-responsive table-borderless" style="border: 1px solid whitesmoke;width:210px;">
                                                                        <thead style="background: #333 !important;color:white;">
                                                <tr align="center">
                                                    <th style="padding: 4px !important;border-right: 1px solid whitesmoke;">Dollar Value</th>
                                                    <th style="padding: 4px !important;">Rate</th>
                                                </tr>
                                            </thead>
						
						<!-- Twenty Five -->	
                                                                                 
<?php 
					  if (empty($twentyfive)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                                <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>25 Dollars</h6></td>
                                <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($twentyfive).'</h6></td>
                            </tr>';
	 }
	 ?>											

	 
	 <!-- Fifty -->	
                                                    <?php 
					  if (empty($fifty)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                               <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>50 Dollars</h6></td>
                               <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($fifty).'</h6></td>
                            </tr>';
	 }
	 ?>		
                                                 

<!-- Hundred -->													 <?php 
					  if (empty($hundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                                <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>100 Dollars</h6></td>
                               <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($hundred).'</h6></td>
                            </tr>';
	 }
	 ?>		
							

<!--Two hundred -->								<?php 
					  if (empty($twohundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                                <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>200 Dollars</h6></td>
                                <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($twohundred).'</h6></td>
                            </tr>';
	 }
	 ?>		
	 
	 <!-- Five hundred -->	
							 <?php 
					  if (empty($fivehundred)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                                <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>500 Dollars</h6></td>
                                <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($fivehundred).'</h6></td>
                            </tr>';
	 }
	 ?>		
							

  <!-- one thousand -->							<?php 
					  if (empty($onethousand)) 
	 {
     echo ""; 
	 }
	 else
	 {
		 
		 echo' <tr>
                               <td style="border-right: 2px solid whitesmoke;border-bottom: 2px solid whitesmoke;"><h6>1000 Dollars</h6></td>
                                <td style="border-bottom: 2px solid whitesmoke;"><h6 class="">&#8358;'.number_format($onethousand).'</h6></td>
                            </tr>';
	 }
	 ?>		
                                            </table></center>
                                            <center><?php echo $type;?></center>
											<br>
											 <a href="trade?name=<?php echo $name;?>" class="bttn-mid btn-fill" style="background-color:gold;height:50px;margin-bottom:5px;">Trade <?php echo $name;?> </a>
				
                                  </div>
            
											</div>
                                                            
                                                        
                                                  <?php

									 } ?>     
                                            </div>
											
</div>
</section>
<!--Pricing Table-->




 <?php

require_once('footer.php');
?>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>