<!DOCTYPE html>
<html>
<head>

<style>
.center{
    margin-top:5px;
    display:block;
    margin-left:auto;
    margin-right:auto;
    width:50%;
}
</style>
</head>

<!--Header Area-->

                
    <div class="header sticky-top" style="color: whitesmoke;padding: 3px; background: var(--cl-black);">
        <div class="container">
            <div class="row">
              
                <!-- logo -->
                <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                  <div id="navigation">
                    <!-- navigation start-->
                    <ul>
                                                    <li><a href="index"><b>Home</b></a></li>
                                                    
                                                    
                           
                            <li><a href="rates"><b>Rates</b></a></li>
                            <li><a href="logout"><b>Logout</b></a></li>
                                        
<!--<li> <a href="https://www.instagram.com/bucksxchange001loader?igshid=thv276lssnhg" style="color: black;font-size: 15px;" class="fa fa-instagram"></a></li> -->
                 <li> <a href="https://api.whatsapp.com/send?phone=2348109499623&text=I want to trade&source=&data=" target="_blank" style="color: #66707f;font-size: 25px;" class="fa fa-whatsapp"></a></li> 
                 
                 <li> <a href="tel:08109499623" style="color: #66707f;font-size: 25px;" class="fa fa-phone"></a></li> 
                    
                    </ul>
                </div>
                <!-- /.navigation start-->
                </div>
            <!-- /.search start-->
        </div>
    </div>
</div>
            
            <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e79b09c35bcbb0c9aa9ada3/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
            
   
    
<section class="custom-banner dark-overlay" style="background: url('assets/images/hero.jpg') no-repeat fixed;">
	<div class="container">
		<div class="row">
			<div class="col-xl-8 col-lg-8 col-md-6 col-sm-12">
				<div class="banner-title">
				  <!--  <img src = "../images/buck.png" alt="bucksxchange logo" class="center" style="background:transparent;width:100px; height:100px;"> -->
					<h2>Trade Home</h2>
					<p>Welcome <?php echo $_SESSION['email']; ?></p>
				</div>
			</div>
		</div>
	</div>
</section>