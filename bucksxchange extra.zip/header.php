<header class="header-area">
<nav class="navbar sticky-top navbar-expand-lg main-menu">
        <div class="container">

            <a class="navbar-brand" href="https://bucksxchange.com.ng/" style="color:#fff;"><img src = "images/buck.png" alt="bucksxchange logo" class="center" style="background:transparent;width:60px; height:60px;"></a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">

                                            <li><a href="https://bucksxchange.com.ng/">Home</a></li>
                        <li><a href="https://bucksxchange.com.ng/#testimony">Feedback</a></li>
                        <li><a href="https://bucksxchange.com.ng/#rates">Our Rates</a></li>
                                                                <li><a href="login">Login</a></li>
                        <li><a href="register">Sign up</a></li>
                                        <li><a href="https://api.whatsapp.com/send?phone=23408109499623&text=I want to trade&source=&data=" target="_blank"><i class="fa fa-whatsapp"></i> 08109499623</a></li>
                </ul>
                                                                <div class="header-btn justify-content-end"><a href="login" class="bttn-small btn-fill" style="background-color:#f51f8a;">Trade Now!</a></div>
                                                            </div>
            </div>
        </nav>
    </header><!--/Header Area-->
            
            <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e79b09c35bcbb0c9aa9ada3/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
            
   
<!--Hero Area-->
<section class="hero-area owl-carousel">
    <div class="single-hero dark-overlay" style="background: url('images/trading.jpg') no-repeat;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12">
                    <div class="hero-sub">
                        <div class="table-cell">
                            <div class="hero-box">
							    <!--<img src = "images/buck.png" alt="bucksxchange logo" class="center" style="background:transparent;width:100px; height:100px;"> -->
                                <h1>let's trade</h1>
                                <p>We buy all kinds of gift cards. We offer you competitive rates, swift payment, reliable Services. </p>
                               
                                <a href="login" class="bttn-mid btn-fill" style="background-color:#f51f8a;border-color:#f51f8a;color:white;">Start A Trade Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--/Hero Area-->