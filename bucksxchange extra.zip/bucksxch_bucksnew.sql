-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 06, 2020 at 07:03 PM
-- Server version: 10.3.23-MariaDB-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bucksxch_bucksnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `updation_Date` varchar(255) NOT NULL,
  `reg_Date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`, `updation_Date`, `reg_Date`) VALUES
(1, 'Bucksxchange', '0e0f2eb72b4106e778dcb0ec0ce5dd91', 'bucksxchange@gmail.com', '20-05-2020 11:42:05 AM', '20-04-2020 1:42:05 PM');

-- --------------------------------------------------------

--
-- Table structure for table `alltrade`
--

CREATE TABLE `alltrade` (
  `id` int(11) NOT NULL,
  `total` varchar(255) NOT NULL,
  `bankname` varchar(255) NOT NULL,
  `accountnumber` varchar(255) NOT NULL,
  `accountname` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `twentyfive` varchar(255) NOT NULL,
  `fifty` varchar(255) NOT NULL,
  `hundred` varchar(255) NOT NULL,
  `twohundred` varchar(255) NOT NULL,
  `fivehundred` varchar(255) NOT NULL,
  `onethousand` varchar(255) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `twentyfive` varchar(255) NOT NULL,
  `fifty` varchar(255) NOT NULL,
  `hundred` varchar(255) NOT NULL,
  `twohundred` varchar(255) NOT NULL,
  `fivehundred` varchar(255) NOT NULL,
  `onethousand` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`id`, `name`, `image`, `type`, `twentyfive`, `fifty`, `hundred`, `twohundred`, `fivehundred`, `onethousand`) VALUES
(1, 'Google', 'google.png', 'WE TRADE US ONLY', '6000', '12000', '27000', '', '', ''),
(2, 'Amazon', 'amazon.png', 'WE TRADE US ONLY', '5000', '12000', '25000', '', '', ''),
(3, 'Steam', 'steam.png', 'WE TRADE US ONLY', '5000', '13000', '27000', '', '', ''),
(4, 'Itunes', 'itunes.png', 'WE TRADE ALL COUNTRTY', '5000', '13000', '26000', '', '', ''),
(5, 'Nike', 'nike.png', '', '', '', '24000', '48000', '120000', ''),
(6, 'Ebay', 'ebay.png', 'WE TRADE US ONLY', '', '', '26000', '520000', '130000', ''),
(7, 'Sephora', 'sephora.png', 'WE TRADE US ONLY', '', '', '23000', '46000', '120000', '');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `no` int(11) NOT NULL,
  `images` varchar(500) NOT NULL,
  `id` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendingtestimony`
--

CREATE TABLE `pendingtestimony` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendingtrade`
--

CREATE TABLE `pendingtrade` (
  `id` int(11) NOT NULL,
  `bankname` varchar(255) NOT NULL,
  `accountnumber` varchar(255) NOT NULL,
  `accountname` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `twentyfive` varchar(255) NOT NULL,
  `fifty` varchar(255) NOT NULL,
  `hundred` varchar(255) NOT NULL,
  `twohundred` varchar(255) NOT NULL,
  `fivehundred` varchar(255) NOT NULL,
  `onethousand` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendingtrade`
--

INSERT INTO `pendingtrade` (`id`, `bankname`, `accountnumber`, `accountname`, `number`, `twentyfive`, `fifty`, `hundred`, `twohundred`, `fivehundred`, `onethousand`, `total`, `cardname`, `email`, `image`) VALUES
(2, 'Zenith Bank International', '6463737388', 'david mike', '09065123411', '15000', '', '', '', '', '', '15000', 'Itunes', 'jiboye@gmail.com', 'box-img2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `testimony`
--

CREATE TABLE `testimony` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimony`
--

INSERT INTO `testimony` (`id`, `name`, `message`) VALUES
(1, 'Huaman', 'Good site'),
(3, 'Akeem eniola', 'A very good site to trade with'),
(4, 'Akeem saheed', 'A very good site to trade with'),
(5, 'Augustine ella', 'I really love your website very fast trade');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `contactNo` varchar(255) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `contactNo`, `email`, `password`) VALUES
(1, '09087543211', 'autoslandmax@gmail.com', '123456'),
(2, '09065123411', 'jiboye@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alltrade`
--
ALTER TABLE `alltrade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `pendingtestimony`
--
ALTER TABLE `pendingtestimony`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendingtrade`
--
ALTER TABLE `pendingtrade`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimony`
--
ALTER TABLE `testimony`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `alltrade`
--
ALTER TABLE `alltrade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `card`
--
ALTER TABLE `card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pendingtestimony`
--
ALTER TABLE `pendingtestimony`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pendingtrade`
--
ALTER TABLE `pendingtrade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `testimony`
--
ALTER TABLE `testimony`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
