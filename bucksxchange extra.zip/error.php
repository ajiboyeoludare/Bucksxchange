<?php
include('powerhouse/config.php');


?>






















<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <title>WELCOME BUCKSXCHANGE TESTIMONY  PAGE </title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
<link href="css/navbar.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div><!--Preloader -->

<!--Header Area-->
             
    <div class="header sticky-top" style="color: whitesmoke;padding: 3px; background: var(--cl-black);">
        <div class="container">
            <div class="row">
              
                <!-- logo -->
                <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                  <div id="navigation">
                    <!-- navigation start-->
                    <ul>
                                                    <li><a href="https://bucksxchange.com.ng/"><b>Home</b></a></li>
                                                    
                                                    
                           
                            <li><a href="#testimony"><b>Feedback</b></a></li>
                            <li><a href="#rates"><b>Our Rates</b></a></li>

                            <li><a href="register.php">
                               
                 <li><a href="login.php"><b>Login</b></a></li> 
                 </ul>
                </div>
                <!-- /.navigation start-->
            </div>
            <!-- /.search start-->
        </div>
    </div>
</div>
       
            
            <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e79b09c35bcbb0c9aa9ada3/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--Hero Area-->


 <section class="custom-banner dark-overlay" style="background: url('assets/images/hero.jpg') no-repeat fixed;">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-6 col-sm-12">
                <div class="banner-title">
                    <h2>Error</h2>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="page-breadcrumb">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Error</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>





<br>
<br>
<br>






<center>Page not found <a href="index">Go Back</a>  to homepage</center>

<br>
<br>
<br>



    <?php

require_once('footer.php');
?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>