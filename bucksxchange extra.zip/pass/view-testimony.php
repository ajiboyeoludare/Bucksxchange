<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_login();

$id = $_GET['id'];
	
	//check if id not exist in database///////////
	 $checkname=mysqli_query($mysqli,"SELECT * FROM pendingtestimony WHERE id='$id'");
     if(mysqli_num_rows($checkname)<1)
    {
	header('location: pending-testimony.php');
}
if(empty($id)) {
	header('location: pending-testimony.php');
}


?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <title>Welcome admin !! View testimony</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
<link rel="stylesheet" href="w3.css">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!---------font awesone---------->
    <script src="https://kit.fontawesome.com/669b300719.js" crossorigin="anonymous"></script>
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript">
function valid()
{

if(document.changepwd.newpassword.value!= document.changepwd.cpassword.value)
{
alert("Password and Re-Type Password Field do not match  !!");
document.changepwd.cpassword.focus();
return false;
}
return true;
}
</script>
<style>
.download-button{
    width:50%;
    margin:auto;
    padding:10px;
    color:white;
    background-color:blue;
    border-color:#f51f8a;
    text-align:center;
}
.trade-button-right{
    position:absolute;
    right:10px;
    width:165px;
    Height:50px;
    border:0px;
    padding:10px;
    background-color:#fa0200;
    color:white;
    text-align:center;
}
.trade-button-left{
    position:absolute;
    left:10px;
    width:165px;
    Height:50px;
    padding:10px;
    background-color:green;
    color:white;
    border-color:#f51f8a;
    text-align:center;
}
</style>
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
  <!-- <h4>BUCKSXCHANGE</h4>-->
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div>
<!--Preloader -->


<?php

require_once('admin-header.php');
?>



<br>
 <?php

            $id = $_GET["id"];

            // select first 3 posts
            $query = "SELECT * FROM pendingtestimony WHERE id='" . $id . "'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){

                
				$name = $row['name'];
				$message = $row['message'];
				
                
			
			}
			?>
			
			<div style="margin-left:15px;"><b> Name:</b> <?php echo $name; ?></div>
			<div style="margin-left:15px;"><b>Message:</b> <?php echo $message; ?></div>
		
			
<br>

			
  
</div>
<br>







<br>

<a onclick="return confirm('Are you sure you want to approve this testimony to show to all users');" href="approve-testimony.php?id=<?php echo $id;?>" class="trade-button-left"><i class="fas fa-check"></i>&nbsp Approve</a>
					
<a onclick="return confirm('Are you sure you want to delete this testimony');" href="delete-testimony.php?id=<?php echo $id;?>" class="trade-button-right"><i class="fas fa-times"></i>&nbsp Delete </a>
					

        
<br>
<br>

<?php

require_once('footer.php');
?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>