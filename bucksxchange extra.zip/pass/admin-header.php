<!--Header Area-->
<header class="header-area">
    <nav class="navbar sticky-top navbar-expand-lg main-menu">
        <div class="container">

            <a class="navbar-brand" href="https://bucksxchange.com.ng/" style="color:#fff;"><img src="images/buck.png" alt="" width="70" height="70"> </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">

                                            <li><a href="admin-welcome">Home</a></li>
                        
                        <li><a href="manage-card">Manage Cards</a></li>
						<li><a href="create-card">Create Cards</a></li>
                                                                <li><a href="manage-users">Manage-users</a></li>
                                                               
																<li><a href="all-trade">All trade</a></li>
																<li><a href="pending-trade">Pending trade</a></li>
																<li><a href="cancel-trade">Cancelled trade</a></li>
																<li><a href="pending-testimony">Confirm testimony</a></li>
																
                        
                </ul>
                                                                <div class="header-btn justify-content-end"><a href="logout" class="bttn-small btn-fill" style="background-color:gold;">Logout</a></div>
                                                            </div>
            </div>
        </nav>
    </header><!--/Header Area-->
    
<section class="custom-banner dark-overlay">
	<div class="container" style="height:10px;">
		<div class="row">
			<div class="col-xl-8 col-lg-8 col-md-6 col-sm-12">
				<div class="banner-title">
					<h2>Welcome To admin Portal</h2>
					
				</div>
			</div>
		</div>
	</div>
</section>
