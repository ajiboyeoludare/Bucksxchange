<?php
session_start();
include('../powerhouse/config.php');
include('../powerhouse/checklogin2.php');
check_login();
?>