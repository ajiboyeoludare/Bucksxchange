<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_login();

?>






<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">


    <title>Welcome admin !! All trade</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

<!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div>
<!--Preloader -->


<?php

require_once('admin-header.php');
?>


<br>
<br>

 <div class="row justify-content-center">
            <div class="col-lg-8 centered wow fadeInUp" data-wow-delay="0.3s">
                <div class="section-title">
                    <h2>All Trades </h2>
                    <p>Below are all the confirmed trade</p>
                </div>
            </div>
        </div>
<!--  CODE BEGINS -->
		
		
		
		
		
		<?php
	require_once("powerhouse/perpage.php");	
	require_once("powerhouse/dbcontroller.php");
	$db_handle = new DBController();
	
	$name = "";
	$code = "";
	
	$queryCondition = "";
	if(!empty($_POST["search"])) {
		foreach($_POST["search"] as $k=>$v){
			if(!empty($v)) {

				$queryCases = array("name","code");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}
				switch($k) {
					case "name":
						$name = $v;
						$queryCondition .= "email LIKE '" . $v . "%'";
						break;
					case "code":
						$code = $v;
						$queryCondition .= "contactNo LIKE '" . $v . "%'";
						break;
				}
			}
		}
	}
	$orderby = " ORDER BY id DESC"; 
	$sql = "SELECT * FROM alltrade " . $queryCondition;
	$href = 'all-trade.php';					
		
	$perPage = 10; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
	$result = $db_handle->runQuery($query);
	
	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}
?>
  		
  	

	
 		   <div id="main">
	
	     
<div class="panel panel-default panel-shadow"  style="margin-left: 20px;margin-right: 20px;">
  <form name="frmSearch" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <div style="border: 1px solid #F0F0F0;background-color: #FFFFFF;margin: 2px 0px;">
			<p><input type="text" placeholder="Search By email" name="search[name]" style="padding: 10px;border: gold 1px solid; border-radius: 4px;margin: 0px 5px;" value="<?php echo $name; ?>"	/>
			
			<input type="submit" name="go" style="padding: 10px;border: #F0F0F0 1px solid; border-radius: 4px;margin: 0px 5px;background-color:gold;" value="Search">
			<input type="reset" style="padding: 10px;border: #F0F0F0 1px solid; border-radius: 4px;margin: 0px 5px;background-color:black;color: white;" value="Reset" onclick="window.location='all-trade.php'"></p>
			</div>
  <div class="panel-body">
         
		 
        <table id="data-table" class="table table-striped table-hover dt-responsive" cellspacing="0" width="100%" style="border: 1px solid grey;">
            <thead>
	            <tr>	    
                      
	                <th class="text-center width-100" style="border-right: 1px solid grey;">Id</th>	
	                <th  class="text-center width-100" style="border-right: 1px solid grey;">Phone No</th>
					<th  class="text-center width-100" style="border-right: 1px solid grey;">Email</th>
				
					<th  class="text-center width-100" style="border-right: 1px solid grey;">Card Name</th>
					<th  class="text-center width-100" style="border-right: 1px solid grey;">Sold Price</th>
					
	                
	            </tr>
            </thead>

            <tbody>
			<?php
					if(!empty($result)) {
						foreach($result as $k=>$v) {
						  if(is_numeric($k)) {
					?>
                     	   <tr>
            	 
<td  style="border-right: 1px solid grey;"><?php echo $result[$k]["id"]; ?></td>
                <td  style="border-right: 1px solid grey;"><?php echo $result[$k]["number"]; ?></td>
				<td  style="border-right: 1px solid grey;"><?php echo $result[$k]["email"]; ?></td>
				<td  style="border-right: 1px solid grey;"><?php echo $result[$k]["cardname"]; ?></td>
				<td  style="border-right: 1px solid grey;">&#8358;<?php echo number_format($result[$k]["total"]); ?></td>
                

               
            </td>
                
            </tr> 
			 <?php
						  }
					   }
                    }
					if(isset($result["perpage"])) {
					?>   
               <tr>
					<td colspan="6" align="center"> <font color="red" class="btn" style="background-color:grey;color:red;"><?php echo $result["perpage"]; ?>&nbsp; </font></td>
					</tr>
					<?php 
					} ?>   
            </tbody>
        </table></form>
    </div>
    
</div>

<br>
<br>

		
		


<!--   CODE ENDS -->
 		   
<?php

require_once('footer.php');
?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>