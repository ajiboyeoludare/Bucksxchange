<?php
require_once("powerhouse/dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["id"])) {
	$query = "DELETE FROM pendingtestimony WHERE id=".$_GET["id"];
	$result = $db_handle->executeQuery($query);
	if(!empty($result)){
		header("Location:pending-testimony.php");
	}
}

?>