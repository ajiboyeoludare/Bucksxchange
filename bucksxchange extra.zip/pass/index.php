<?php
session_start();
include('powerhouse/config.php');
if(isset($_POST['login']))
{
    
$username=mysqli_real_escape_string($mysqli,$_POST['username']);
$password=mysqli_real_escape_string($mysqli,$_POST['password']);
$password = md5($password);
$stmt=$mysqli->prepare("SELECT username,email,password,id FROM admin WHERE (userName=?|| email=?) and password=? ");
				$stmt->bind_param('sss',$username,$username,$password);
				$stmt->execute();
				$stmt -> bind_result($username,$username,$password,$id);
				$rs=$stmt->fetch();
				$_SESSION['id']=$id;
				$uip=$_SERVER['REMOTE_ADDR'];
				$ldate=date('d/m/Y h:i:s', time());
				if($rs)
				{
                //  $insert="INSERT into admin(adminid,ip)VALUES(?,?)";
   // $stmtins = $mysqli->prepare($insert);
   // $stmtins->bind_param('sH',$id,$uip);
    //$res=$stmtins->execute();
					header("location:admin-welcome");
				}

				else
				{
					echo "<script>alert('Invalid Username/Email or password');</script>";
				}
			}
				?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Admin login</title>

	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<center>
	<br>
	<br>
	<br>
							<h3 style="color: gold;">Admin Login</h3>
	<div class="panel panel-default" style="border:1px solid black;width:60%;">
									<div class="panel-heading" style="background-color:black;border:1px solid black;color:white;padding:5px;"><img src="images/bucksxchange.jpg" alt="" width="50px" height="50px"></div>
									<div class="panel-body">

						
							

								<form action="" class="mt" method="post">
									<label for="" class="text-uppercase text-sm" style="color:grey;"><b> Email</b></label>
									<input type="text" placeholder="Username" name="username" class="form-control mb" style="border-color:gold;width:60%;">
									<label for="" class="text-uppercase" style="color:grey;"><b>Password</b></label>
									<input type="password" placeholder="Password" name="password" class="form-control mb" style="border-color:gold;width:60%;">

<br>
									<input type="submit" name="login" class="btn btn-primary btn-block" value="Login" style="border-color:gold;width:60%;background-color:gold; border-color:gold;">
								
								<br>
								</form>
								</div>
								</div>
								</div>
								</center>
							
					
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>




<style> .foot{text-align: center; border: 1px solid black;}</style>
</html>
