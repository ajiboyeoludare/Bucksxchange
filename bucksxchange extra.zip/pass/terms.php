<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_login();

//code for add courses
 $messageError =   "";
 $message =  "";

if (isset($_POST["submit"]))  {
//retrive form values

$message=mysqli_real_escape_string($mysqli,$_POST['message']);






 //validating firstname input value
	 
	 
	 if (empty($message)||strlen($message)<3) 
	 {
     $messageError = "Your message too short or empty"; 
	 }
	 
    
	 
	 
	 //insert into database
	  if (!$nameError)	
if (!$messageError)			  
	 {
	   
	$sql="INSERT INTO terms (message) VALUES ('$message')";
	mysqli_query($mysqli,$sql);
	$current_id = mysqli_insert_id($mysqli);

	if(!empty($current_id)) {
		$message = "Terms added";
	}
}
}

?>






<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">


    <title>Welcome admin !! Manage Users</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

<!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div>
<!--Preloader -->


<?php

require_once('admin-header.php');
?>


<br>
<br>

 <div class="row justify-content-center">
            <div class="col-lg-8 centered wow fadeInUp" data-wow-delay="0.3s">
                <div class="section-title">
                    <h2>Add Terms and condition</h2>
                    
                </div>
            </div>
        </div>
<!--  CODE BEGINS -->
		
		<div class="row">
            <div class="col-xl-6 col-lg-6 col-sm-6">
                <div class="contact-form">
                  
                                        <center<>
                                            <form action=""  method="post">
										<font color="red"><h6><?php if(isset($message)) { echo $message; } ?></h6></font>
                        
                        <div class="single-field">
                            <label for="message">Message</label>
							<font color="red"><?php echo $messageError;?></font>
                            <textarea name="message"  rows="4"></textarea>
                        </div>
                        
                        <button type="submit" class="bttn-mid btn-fill" name="submit">Add Terms</button>
                    </form>
                    </center>
                </div>
            </div>
        </div>
		
	

<br>
<br>

		
		


<!--   CODE ENDS -->
 		   
<?php

require_once('footer.php');
?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>