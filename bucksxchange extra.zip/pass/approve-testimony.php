<?php
require_once("powerhouse/dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["id"])) {
	$query = "INSERT INTO testimony (name,message)
	SELECT name, message 
	FROM pendingtestimony  WHERE id=".$_GET["id"];
	$result = $db_handle->executeQuery($query);
}
if(!empty($result))
{
	 $query2 = "DELETE FROM pendingtestimony WHERE id=".$_GET["id"];
    $result2 = $db_handle->executeQuery($query2);
	
    
	if(!empty($result2)){
		header("Location:pending-testimony.php");
	}
}
?>