<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_login();
//code for add courses
$nameError =  $imageError =  "";
$name =  $twentyfive = $fifty = $hundred  = $twohundred = $fivehundred = $onethousand = $type = "";

if (isset($_POST["submit"]))  {
//retrive form values
$name=mysqli_real_escape_string($mysqli,$_POST['name']);
$twentyfive=mysqli_real_escape_string($mysqli,$_POST['twentyfive']);
$fifty=mysqli_real_escape_string($mysqli,$_POST['fifty']);
$hundred=mysqli_real_escape_string($mysqli,$_POST['hundred']);
$twohundred=mysqli_real_escape_string($mysqli,$_POST['twohundred']);
$fivehundred=mysqli_real_escape_string($mysqli,$_POST['fivehundred']);
$onethousand=mysqli_real_escape_string($mysqli,$_POST['onethousand']);
$type=mysqli_real_escape_string($mysqli,$_POST['type']);
$id=$_GET['id'];


  if (empty($name)||strlen($name)<3) 
	 {
     $nameError = "Card name too short"; 
	 }
	 
    
	 
	 //insert into database
	  if (!$nameError)		
	 {
		 $sql = "UPDATE card set name = '".$_POST["name"]."', twentyfive='$twentyfive', fifty='$fifty', hundred='$hundred', twohundred='$twohundred', fivehundred='$fivehundred', onethousand='$onethousand' , type='$type' WHERE  id=".$id;
	mysqli_query($mysqli,$sql);
	
		$message = "Card Details Edited Successfully";
	}
}



?>



<?php

if (isset($_POST["updateimage"]))  {
//retrive form values
$name = $_FILES['img']['name'];
  $target_dir = "../images/";
  $target_file = $target_dir . basename($_FILES["img"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){
 
    // Convert to base64 
    $image = $_FILES['img']['name'];
   
   
  
    // Upload file
    move_uploaded_file($_FILES['img']['tmp_name'],$target_dir.$name);
  }


$id=$_GET['id'];


 if(!in_array($imageFileType,$extensions_arr))
		 {
     $imageError = "$imageFileType is not an allowed file type"; 
	 }
	 
	 // //insert into database
	  if (!$imageError)		
	 {
		 include('powerhouse/config.php');
		 $sql = "UPDATE card set image ='$image' WHERE id=".$id;
	mysqli_query($mysqli,$sql);
	
		$imagemessage = "Image Changed Successfully";
	 }
	
}



?>


<?php	
												$id=$_GET['id'];
	$ret="select * from card where id=?";
		$stmt= $mysqli->prepare($ret) ;
	 $stmt->bind_param('i',$id);
	 $stmt->execute() ;//ok
	 $res=$stmt->get_result();
	 //$cnt=1;
	  $row=$res->fetch_object()
	  
	  	?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <title>Welcome admin !! Edit Card Details</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">


    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript">
function valid()
{

if(document.changepwd.newpassword.value!= document.changepwd.cpassword.value)
{
alert("Password and Re-Type Password Field do not match  !!");
document.changepwd.cpassword.focus();
return false;
}
return true;
}
</script>

</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <h4>BUCKSXCHANGE</h4>
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div>
<!--Preloader -->


<?php

require_once('admin-header.php');
?>



<br>
<br>
<center>
<div class="container-fluid">

								<div class="col-md-6">
								<div class="panel panel-default" style="border:1px solid black;">
									<div class="panel-heading" style="background-color:black;border:1px solid black;color:white;padding:5px;">Edit&nbsp; <font color="white"><?php echo $row->name; ?> Card</font></div>
									<div class="panel-body">
									<br>
									<form method="post" action="" enctype="multipart/form-data">
							<font color="red"><h6><?php if(isset($imagemessage)) { echo $imagemessage; } ?></h6></font><br>				
									
									<div class="form-group">
												<label class="col-sm-4 control-label"><b>Select Card Image</b></label>
												<div class="col-sm-8">
												<font color="red"><?php echo $imageError;?></font>
												<input type="file" name="img" style="border-color:gold;color:black;width:60%;" required>
												</div>
											</div>
																							<div class="col-sm-6 col-sm-offset-4">
													
													<input type="submit" name="updateimage" Value="Change Card Image" class="btn btn-primary" style="background-color:black; border-color:black;color:white;">
											</div>
<br>
										</form>
											
											
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="form-horizontal" enctype="multipart/form-data">
				
					<?php	
												$id=$_GET['id'];
	$ret="select * from card where id=?";
		$stmt= $mysqli->prepare($ret) ;
	 $stmt->bind_param('i',$id);
	 $stmt->execute() ;//ok
	 $res=$stmt->get_result();
	 //$cnt=1;
	   while($row=$res->fetch_object())
	  {
	  	?>
				
				
				
<font color="red"><h6><?php if(isset($message)) { echo $message; } ?></h6></font>
 							
											<div class="form-group">
												<label class="col-sm-4 control-label"><b>Card Name</b></label>
												<div class="col-sm-8">
												<font color="red"><?php echo $nameError;?></font>
				<input type="text" value="<?php echo $row->name;?>" name="name" class="form-control" required="required" style="border-color:gold;color:black;width:50%;">
									 <span id="password-availability-status" class="help-block m-b-none" style="font-size:12px;"></span> </div>
											</div>
									<div class="form-group">
												
												<div class="col-sm-8">
												<label class="radio-inline">
												    
                        <input type="radio" value="WE TRADE US ONLY" name="type"> US ONLY</label>&nbsp;&nbsp;&nbsp;
                    <label class="radio-inline">
                        <input type="radio" value="WE TRADE ALL COUNTRTY" name="type"> ALL COUNTRY</label>
												</div>
											</div>			
<div class="form-group">
									<label class="col-sm-4 control-label"><b>$25 Price in Naira</b><br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->twentyfive;?>" name="twentyfive" class="form-control" style="border-color:gold;color:black;width:50%;">									</div>
											</div>
											<div class="form-group">
									<label class="col-sm-4 control-label"><b>$50 Price in Naira</b><br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->fifty;?>" name="fifty" class="form-control"  style="border-color:gold;color:black;width:50%;">										</div>
											</div>
											<div class="form-group">
									<label class="col-sm-4 control-label"><b>$100 Price in Naira</b><br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->hundred;?>" name="hundred" class="form-control" style="border-color:gold;color:black;width:50%;">									</div>
											</div>
											<div class="form-group">
									<label class="col-sm-4 control-label"><b>$200 Price in Naira </b> <br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->twohundred;?>" name="twohundred" class="form-control" style="border-color:gold;color:black;width:50%;">									</div>
											</div>
											<div class="form-group">
									<label class="col-sm-4 control-label"><b>$500 Price in Naira </b><br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->fivehundred;?>" name="fivehundred" class="form-control" style="border-color:gold;color:black;width:50%;">									</div>
											</div>
											<div class="form-group">
									<label class="col-sm-4 control-label"><b>$1000 Price in Naira </b><br><small style="color:red;">(live empty if not available)</small></label>
									<div class="col-sm-8">
				<input type="number" value="<?php echo $row->onethousand;?>" name="onethousand" class="form-control" style="border-color:gold;color:black;width:50%;">									</div>
											</div>
											

<?php } ?>

												<div class="col-sm-6 col-sm-offset-4">
													
													<input type="submit" name="submit" Value="Create Card Type" class="btn btn-primary" style="background-color:black; border-color:black;color:white;">
											</div>
<br>
										</form>

									</div>
								</div>
							</div>
							</div>
						
									
							
</center>


		<!--/container-->
        
<br>
<br>

<?php

require_once('footer.php');
?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>