<?php
session_start();
include('powerhouse/config.php');
include('powerhouse/checklogin.php');
check_login();
?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <title>Welcome admin !! View Card</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
<link rel="stylesheet" href="w3.css">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!---------font awesone---------->
    <script src="https://kit.fontawesome.com/669b300719.js" crossorigin="anonymous"></script>
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	<script type="text/javascript" src="js/validation.min.js"></script>
<script type="text/javascript">
function valid()
{

if(document.changepwd.newpassword.value!= document.changepwd.cpassword.value)
{
alert("Password and Re-Type Password Field do not match  !!");
document.changepwd.cpassword.focus();
return false;
}
return true;
}
</script>
<style>
.download-button{
    width:50%;
    margin:auto;
    padding:10px;
    color:white;
    background-color:blue;
    border-color:#f51f8a;
    text-align:center;
}
.trade-button-right{
    position:absolute;
    right:10px;
    width:165px;
    Height:50px;
    border:0px;
    padding:10px;
    background-color:#fa0200;
    color:white;
    text-align:center;
}
.trade-button-left{
    position:absolute;
    left:10px;
    width:165px;
    Height:50px;
    padding:10px;
    background-color:green;
    color:white;
    border-color:#f51f8a;
    text-align:center;
}
</style>
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
  <!-- <h4>BUCKSXCHANGE</h4>-->
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div>
<!--Preloader -->


<?php

require_once('admin-header.php');
?>



<br>
 <?php

            $id = $_GET["id"];

            // select first 3 posts
            $query = "SELECT * FROM pendingtrade WHERE id='" . $id . "'";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){

                
				$cardname = $row['cardname'];
				$number = $row['number'];
				$email = $row['email'];
				$cardname = $row['cardname'];
				$bankname = $row['bankname'];
				$accountname = $row['accountname'];
				$accountnumber = $row['accountnumber'];
				$total = $row['total'];
				$image = $row['image'];
				
                
			
			}
			?>
			
			<div style="margin-left:15px;"><b>Card Name:</b> <?php echo $cardname; ?></div>
			<div style="margin-left:15px;"><b>Phone number:</b> <?php echo $number; ?></div>
			<div style="margin-left:15px;"><b>Email:</b> <?php echo $email; ?></div>
			<div style="margin-left:15px;"><b>Account details: </b><u> <?php echo $accountnumber; ?></u> <?php echo $accountname; ?> <?php echo $bankname; ?></div>
			<div style="margin-left:15px;"><b>Total Price:</b> &#8358;<?php echo number_format($total); ?></div>
			
<br>
<div class="w3-row-padding">
  <div class="w3-container w3-third">
    <img src="../users/images/<?php echo $image; ?>" style="width:70%;border:1px solid black;margin-bottom:10px;"
    onclick="onClick(this)"
    class="w3-hover-opacity">
    <br>
	<a href="../users/images/<?php echo $image; ?>" class="download-button";"text-align:center;">Download Card</a>
  </div>
  
			
  
</div>
<br>






<div id="m01" class="w3-modal" onclick="this.style.display='none'">
  <span class="w3-closebtn w3-hover-red w3-container w3-padding-16 w3-display-topright">×</span>
  <img class="w3-modal-content w3-animate-zoom" id="img01" style="width:100%">
</div>

<script>
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("m01").style.display = "block";
}
</script>



<a onclick="return confirm('Are you sure you want to confrim this card');" href="confirm-card.php?id=<?php echo $id;?>" class="trade-button-left"><i class="fas fa-check"></i>&nbsp Complete Trade </a>
					
<a onclick="return confirm('Are you sure you want to cancel this trade');" href="cancel.php?id=<?php echo $id;?>" class="trade-button-right"><i class="fas fa-times"></i>&nbsp Cancel Trade </a>
					


        
<br>
<br>

<?php

require_once('footer.php');
?>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>