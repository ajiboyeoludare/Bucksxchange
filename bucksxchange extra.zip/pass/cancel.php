<?php
require_once("powerhouse/dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["id"])) {
	$query = "INSERT INTO canceltrade (bankname,accountname,accountnumber,number,twentyfive,fifty,hundred,twohundred,fivehundred,onethousand,total,cardname,email)
	SELECT bankname, accountname, accountnumber, number, twentyfive, fifty, hundred, twohundred, fivehundred, onethousand, total, cardname, email 
	FROM pendingtrade  WHERE id=".$_GET["id"];
	$result = $db_handle->executeQuery($query);
}
if(!empty($result))
{
	 $query2 = "DELETE FROM pendingtrade WHERE id=".$_GET["id"];
    $result2 = $db_handle->executeQuery($query2);
	
    
	if(!empty($result2)){
		header("Location:pending-trade.php");
	}
}
?>