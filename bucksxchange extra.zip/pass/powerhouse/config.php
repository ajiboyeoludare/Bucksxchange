<?php
$dbuser="bucksxch_bucksnew";
$dbpass="70Xr2GYrBn\=3z!&P";
$host="localhost";
$db="bucksxch_bucksnew";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>