<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
					<li><a href="addapartment.php"> <i class="fa fa-cubes"></i>Add Apartment</i> </a>
					
					<ul>
					<li><a href="all-apartment.php"><font color="red">All Apartment (client view)</font></a></li>
						<li><a href="create-apartment.php">Add an Apartment</a></li>
						<li><a href="manage-apartment.php">Manage Apartment</a></li>
					</ul></li>
					
					
				
				<li><a href="manage-users.php"><i class="fa fa-users"></i>Manage Users</a></li>
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i>Manage bookings</a></li>
				<li><a href="manage-existing.php"><i class="fa fa-file"></i>Existing Applicant Form</a></li>

			
		</nav>