<footer class="footer-area section-padding-2" style="line-height: 20px;>

<!--steps Area-->
<div class="container">
        <div class="row">
        <div class="col-md-6 col-lg-2">
      </div>
            <div class="col-md-6 col-lg-5">
      
           
		  <div class="" data-wow-delay="0.4s">
                    
                    <h4 style="color: whitesmoke;margin-left:15px;"><b>About Us</b></h4>
                            
                    <p  style="color: grey;margin-left:15px;">We are professionals, we buy all type of gift cards, we have been tested and trusted,also you can gain our full trust. In terms of payment,
                    fast delivery is guarantee</p>
                   
                          
            </div>
			</div>
		<br>
		<br>
        
<div class="col-lg-3 col-md-5">
<div class="" data-wow-delay="0.4s">
                 <h4 style="color: whitesmoke;margin-left:15px;margin-top:15px;margin-bottom:5px;"><b>Contact Us</b></h4>
                    
                
                    <div class=""  style="color: grey;">
                        <ul style="margin-bottom:3px;">
                           
                           <li style="margin-bottom:3px;margin-left:15px;">
                            <i class="fas fa-map-marker-alt"></i>&nbsp No 34 Ijaye Road Ogba,Lagos State
                       </li>
                            <li style="margin-bottom:3px;margin-left:15px;">
                            <i class="fa fa-phone"></i>&nbsp 08109499623
                       </li>
                          
                            <li style="margin-top:3px;margin-left:15px;"> <i class="fa fa-envelope"></i>&nbsp info@bucksxchange.com.ng</li>
                            </ul>
                        
                    </div>
                    </div>
                    
                </div>
                </div>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="copyright centered" style="font-size: 14px;">
                        <p  style="color: grey;">&copy;2020 BUCKSXCHANGE. All rights reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </footer><!--/Footer Area-->
</html>