<!--Testimonial Area-->
<section class="testimonial-area section-padding gray-bg"  id="testimony">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 centered wow fadeInUp" data-wow-delay="0.3s">
                <div class="section-title">
                    <h2>What our clients say about us</h2>
                    <p>Testimonials</p>
                </div>
            </div>
        </div>
              
                            
            <div class="col">
                 <div class="row">
		  <div class="testimonials owl-carousel mb-20 wow fadeInUp" data-wow-delay="0.4s">
                                                 <?php

            

            // select first 3 posts
            $query = "select * from testimony";
            $result = mysqli_query($mysqli,$query);

            while($row = mysqli_fetch_array($result)){

                $message = $row['message'];
                $name = $row['name'];
				
	
						   ?>               <div class="single-testimonial">
                            <h4><?php echo $name; ?></h4>

                            <p><?php echo $message; ?></p>
                        </div>
                                            
                                            
                                     <?php } ?>  </div>
                <div class="centered wow fadeInUp" data-wow-delay="0.5s">
                    <a href="testimonies" class="bttn-mid btn-fill" style="background-color:#f51f8a;border-color:#f51f8a;color:white;">Explore All Reviews</a>
             </div>
            </div>
			
			
        </div>
    </div>
</section><!--/Testimonial Area-->    <!--Footer Area-->


