<?php
session_start();

include('powerhouse/config.php');

//code for add courses
$nameError = $addressError =  $contactnoError = $emailidError = $passwordError =   "";
$name =  $address = $contactno = $emailid = $password_1 =  $cpassword = "";

if (isset($_POST["submit"]))  {
//retrive form values




$contactno=$_POST['contact'];
$emailid=$_POST['email'];
$password_1=$_POST['password'];
$cpassword=$_POST["cpassword"];




$contactno=mysqli_real_escape_string($mysqli,$_POST['contact']);
$emailid=mysqli_real_escape_string($mysqli,$_POST['email']);
$password_1=mysqli_real_escape_string($mysqli,$_POST['password']);
$cpassword=mysqli_real_escape_string($mysqli,$_POST['cpassword']);



	   
	  
	 

	 
     
	 //validating password and confirm password
	 if (empty($password_1)||strlen($password_1)<4) 
	 {
     $passwordError = "Password too short";
     }
	 if(strlen($password_1)>20)
     {
     $passwordError = "Password too long";
     }
	 if( $password_1 != $cpassword )
	 {
	 $passwordError = "Confirm password do not match";
	 }
	 
	 //validating email input value
	 if(!preg_match("/([\w\-]+\@[\w\-]+.[\w\-]+)/", $emailid) || strlen($emailid)<4)
     {
      $emailidError="invalid email address entered";
     }
	 //////////////////check if email have aleady been used////////////////
     $checkemail=mysqli_query($mysqli,"SELECT * FROM users WHERE email='$emailid'");

     if(mysqli_num_rows($checkemail)>0)
     {
     $emailidError="Email already been used";
     }
	 //validating phone number
	 $checknumber=mysqli_query($mysqli,"SELECT * FROM users WHERE contactNo='$contactno'");
	 if(mysqli_num_rows($checknumber)>0)
    {
     $contactnoError="This phone number already been used";
    }
	//////////////////check if numeric character only contain/////////
     if(!preg_match("/^[0-9]*$/",$contactno)) 
	 {
	 $contactnoError = "Only Numberic character allowed";
     }
	 if(strlen($contactno)<8)
     {
     $contactnoError="Invalid number entered";
     }











    
	 
	 //insert into database
	
if (!$emailidError)	
if (!$contactnoError)	
if (!$passwordError)	
	
	 {
	     $password = md5($password_1);//encrypt the password before saving in the database
	$sql="INSERT INTO users(contactNo,email,password) VALUES ('$contactno','$emailid','$password')";
	mysqli_query($mysqli,$sql);
	$current_id = mysqli_insert_id($mysqli);
	$last_id = $mysqli->insert_id;
	$_SESSION['id']=$last_id;
				$_SESSION['email']=$emailid;
				$_SESSION['login']=$emailid;
				$uip=$_SERVER['REMOTE_ADDR'];
				$ldate=date('d/m/Y h:i:s', time());
	
	if(!empty($current_id)) {

header("location:users/index.php");
				}
	
}
}


?>








<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <title>Welcome to BUCKSXCHANGE</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/navbar.css" rel="stylesheet">
    <link href="css/pe-icon-7-stroke.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/magnific-popup.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- Icon font CSS -->
	<link href="pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" />
	<link href="pe-icon-7-stroke/css/helper.css" rel="stylesheet" />
    
    <!-- Main css -->
    <link href="css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://hayageek.github.io/jQuery-Upload-File/4.0.11/uploadfile.css" rel="stylesheet">
    <script src="js/jquery-3.2.1.min.js"></script>
    
    <script src="https://hayageek.github.io/jQuery-Upload-File/4.0.11/jquery.uploadfile.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
	
</head>

<body>

 <!-- Preloader -->
 <div class="preloader">
   <!-- <h4>BUCKSXCHANGE</h4 -->
   <img src="images/bucksxchange.jpg" alt="" width="50" height="50">
</div><!--Preloader -->

<!--Header Area-->



             
    <div class="header sticky-top" style="color: whitesmoke;padding: 3px; background: var(--cl-black);">
        <div class="container">
            <div class="row">
              
                <!-- logo -->
                <div class="col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                  <div id="navigation">
                    <!-- navigation start-->
                    <ul>
                                                    <li><a href="https://bucksxchange.com.ng/"><b>Home</b></a></li>
                                                    
                                                    
                           
                            <li><a href="#testimony"><b>Feedback</b></a></li>
                            <li><a href="#rates"><b>Our Rates</b></a></li>

                            <li><a href="register">
                               
                 <li><a href="login"><b>Login</b></a></li> 
                 </ul>
                </div>
                <!-- /.navigation start-->
            </div>
            <!-- /.search start-->
        </div>
    </div>
</div>
       
       
            
            <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e79b09c35bcbb0c9aa9ada3/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
            
   <!--/Header Area-->
    
<!--Hero Area-->


<section class="custom-banner dark-overlay" style="background: url('assets/images/hero.jpg') no-repeat fixed;">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-6 col-sm-12">
                <div class="banner-title">
                    <h2>Sign up</h2>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12">
                <div class="page-breadcrumb">
                    <ul>
                        <li><a href="https://bucksxchange.com.ng/">Home</a></li>
                        <li>Sign up</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="partner-form section-padding gray-bg">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 centered wow fadeInUp" data-wow-delay="0.3s">
                <div class="section-title">
                    <h2>Sign up for an Account</h2>
                </div>
            </div>
        </div>            
        <div class="row justify-content-center wow fadeInUp" data-wow-delay="0.4s">

            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                <div class="resp"></div>
				<div class="container">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="row apply-form regForm">
				<font color="red"><?php echo $contactnoError;?></font>
                    <input type="text" name="contact" placeholder="Phone Number"  value="<?php echo $contactno;?>"required>                    
                        <font color="red"><?php echo $emailidError;?></font>
                    <input type="email" name="email" placeholder="Email Address" value="<?php echo $emailid;?>" required>
                    
                     <font color="red"><?php echo $passwordError;?></font>
                    <input type="password" name="password" placeholder="Password" value="<?php echo $password_1;?>" required>
					 <input type="password" name="cpassword" placeholder="Confirm Password" value="<?php echo $cpassword;?>" required>


                    <button type="submit" class="bttn-mid btn-fill reg_btn" name="submit" style="background-color:#f51f8a;border-color:#f51f8a;color:white;">Register</button>

                </form>
				</div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-12">
                <p>&nbsp;</p>
                <p>Have an account? <a href="login">Login Here</a></p>
            </div>
        </div>
    </div>
</section>








    <?php

require_once('footer.php');
?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-migrate.js"></script>

    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>

    <script src="js/magnific-popup.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/scrollUp.min.js"></script>


    <script src="js/script.js"></script>

</body>
</html>